/**
 * @program school-bus
 * @description: PayResponse
 * @author: mf
 * @create: 2020/03/17 16:55
 */

package com.dream.bus.pay;

import com.dream.bus.param.AbstractResponse;
import lombok.Data;

@Data
public class PayResponse extends AbstractResponse {

}
