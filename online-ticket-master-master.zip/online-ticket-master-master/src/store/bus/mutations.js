export default {
  SEAT_LIST(state, seats) {
    state.seatList = seats
  },
}